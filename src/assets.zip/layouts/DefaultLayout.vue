<template>
  <div class="min-h-screen flex flex-col bg-[#0F172A] text-white">
    <!-- Header -->
    <header class="flex justify-between items-center p-6 bg-gray-900 shadow-md fixed w-full z-10">
      <h1 class="text-2xl font-bold tracking-tight">Aleksei Kagan</h1>
      <nav class="flex gap-6">
        <RouterLink to="/" class="nav-link" exact-active-class="active-link">
          Home
        </RouterLink>
        <RouterLink to="/frontend" class="nav-link" exact-active-class="active-link">
          Frontend
        </RouterLink>
        <RouterLink to="/telegram" class="nav-link" exact-active-class="active-link">
          Telegram Bots
        </RouterLink>
        <RouterLink to="/ai" class="nav-link" exact-active-class="active-link">
          AI Pro
        </RouterLink>
      </nav>
    </header>

    <!-- Main content -->
    <main class="flex-grow relative overflow-hidden">
      <slot />
    </main>

    <!-- Footer -->
    <footer class="bg-gray-900 p-4 text-center text-gray-400 text-sm">
      © 2025 Aleksei Kagan
    </footer>
  </div>
</template>

<script setup>
import { RouterLink } from 'vue-router'
</script>

<style scoped>
.nav-link {
  position: relative;
  font-weight: 500;
  transition: color 0.3s;
}

.nav-link:hover {
  color: #38bdf8;
}

.active-link {
  color: #38bdf8;
  font-weight: 700;
}
</style>
