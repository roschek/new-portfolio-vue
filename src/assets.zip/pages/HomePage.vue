<template>
  <section ref="vantaRef" class="relative w-full h-screen overflow-hidden flex items-center justify-center p-8">
    <div class="relative z-10 text-center">
      <h1 class="text-4xl md:text-6xl font-bold text-white mb-6 leading-tight">
        <span v-for="(letter, index) in titleArray" :key="index" class="inline-block opacity-0 animate-fade-in"
          :style="{ animationDelay: (index * 0.05) + 's' }">
          <template v-if="letter === ' '">&nbsp;</template>
          <template v-else>{{ letter }}</template>
        </span>

      </h1>
      <p class="text-lg md:text-2xl text-gray-300">
        Creating Interfaces, Automating Workflows, Powering Ideas.
      </p>
    </div>
  </section>
</template>

<script setup>
import { ref, onMounted, onBeforeUnmount } from 'vue'
import * as THREE from 'three'
import WAVES from 'vanta/dist/vanta.waves.min'

const vantaRef = ref(null)
const vantaEffect = ref(null)

const title = 'Hi, I am Aleksei Kagan - Software Engineer.'
const titleArray = title.split('')

onMounted(() => {
  if (!vantaEffect.value) {
    vantaEffect.value = WAVES({
      el: vantaRef.value,
      THREE,
      color: 0x38bdf8,
      shininess: 50,
      waveHeight: 20,
      waveSpeed: 1,
      zoom: 0.85,
    })
  }
})

onBeforeUnmount(() => {
  if (vantaEffect.value) vantaEffect.value.destroy()
})
</script>

<style scoped>
@keyframes fade-in {
  0% {
    opacity: 0;
    transform: translateY(10px);
  }

  100% {
    opacity: 1;
    transform: translateY(0);
  }
}

.animate-fade-in {
  animation: fade-in 0.5s forwards;
}
</style>
