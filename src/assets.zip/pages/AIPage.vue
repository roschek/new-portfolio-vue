<template>
  <section class="px-8 py-8 bg-[#0F172A] text-white h-screen">
    <h2 class="text-4xl font-bold mb-4">AI Page</h2>
    <p class="text-lg text-gray-600">Давайте создадим что-то удивительное вместе.</p>
  </section>
</template>

<script setup>
</script>