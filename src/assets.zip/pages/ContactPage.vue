<template>
  <section class="flex flex-col justify-center items-center h-screen">
    <h2 class="text-4xl font-bold mb-4">Contact page</h2>
    <p class="text-lg text-gray-600">Давайте создадим что-то удивительное вместе.</p>
  </section>
</template>

<script setup>
</script>