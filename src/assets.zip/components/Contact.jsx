function Contact() {
  return (
    <section className="p-10 text-center">
      <h2 className="text-3xl font-bold">Контакты</h2>
      <p className="mt-4 text-lg">Свяжитесь со мной через GitHub или Telegram.</p>
    </section>
  );
}

export default Contact;