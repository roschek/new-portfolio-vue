function Projects() {
  return (
    <section className="p-10 text-center bg-gray-100 dark:bg-gray-800">
      <h2 className="text-3xl font-bold">Проекты</h2>
      <p className="mt-4 text-lg">Мои лучшие работы скоро появятся здесь!</p>
    </section>
  );
}

export default Projects;