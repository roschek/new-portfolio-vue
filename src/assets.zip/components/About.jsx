function About() {
  return (
    <section className="p-10 text-center">
      <h2 className="text-3xl font-bold">Обо мне</h2>
      <p className="mt-4 text-lg">Я специализируюсь на React, Next.js и Tailwind CSS.</p>
    </section>
  );
}

export default About;